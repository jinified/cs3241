A011213E

Main concept:
I am drawing a throne with overlapping pillars which blends each others color.
There is also a star shape core for the throe which consists of LINE_STIPPLE.

Primtives and Transformation:
- GL_POINT, GL_POLYGON
- simple pillar shapes
- glRotateF
- glTranslateF
- glScaleF
- star shape

Coolest thing:
- Usage of GL_BLEND allows more interesting color and pattern
- Usage of GL_LIGHT to add two light sources which increases realism of the object
- Usage of GL_LINE_STIPPLE to create line patterns
