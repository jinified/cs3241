A0112213E

Primtives and Transformation:
- GL_LINE_STRIP, GL_POLYGON
- glTranslateF
- glRotateF


Coolest thing:
- uses glTimerFunc instead of the normal glIdleFunc 
- stars that shines and fades as time passes by 
- a spacecraft object that orbits in elliptical pattern
- combines in place rotation and bouncing of a planet
- blending of planet to create shadow like effect
